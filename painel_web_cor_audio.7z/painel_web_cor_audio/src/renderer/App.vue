<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: 'painel-web'
  }
</script>

<style>
  @import "~bulma/css/bulma.css";
  @import "~font-awesome/css/font-awesome.min.css";
</style>
